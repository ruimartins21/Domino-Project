var files =
[
    [ "core.c", "core_8c.html", "core_8c" ],
    [ "core.h", "core_8h.html", "core_8h" ],
    [ "files.c", "files_8c.html", "files_8c" ],
    [ "files.h", "files_8h.html", "files_8h" ],
    [ "interface.c", "interface_8c.html", "interface_8c" ],
    [ "interface.h", "interface_8h.html", "interface_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "utils.c", "utils_8c.html", "utils_8c" ],
    [ "utils.h", "utils_8h.html", "utils_8h" ]
];