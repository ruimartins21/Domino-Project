var utils_8c =
[
    [ "blockIsPresent", "utils_8c.html#ae7db18b4ee8f5efdb35edc0101e0c849", null ],
    [ "checkExtension", "utils_8c.html#a382054c8b29508312045af99e9b7b211", null ],
    [ "checkId", "utils_8c.html#a3785675cf18028084070b6b9084ef30d", null ],
    [ "createDynamicString", "utils_8c.html#a9c595b6230e08769d7c1560f3707e7a7", null ],
    [ "fileExists", "utils_8c.html#a33cb94f417fea8099841cefc9162542f", null ],
    [ "freeGame", "utils_8c.html#a20c023462aa6e20125f7533b28a991ed", null ],
    [ "getGame", "utils_8c.html#a436e45ca579d6ee173fb26f82d3675a8", null ],
    [ "gettimeuseconds", "utils_8c.html#a82c8fe5237ffab8806520a9c3e6d5629", null ],
    [ "peepBlock", "utils_8c.html#a8307b43310348ab186bb20ed4a9f116b", null ],
    [ "popBlock", "utils_8c.html#a718b153ac66cdc04c92b9344f6c2efca", null ],
    [ "printSingleHand", "utils_8c.html#ab2dd5cfe4f26be348d94206ef04db5df", null ],
    [ "removeBlock", "utils_8c.html#afe6153a014b851d29f0bff3366ae182e", null ],
    [ "swapBlock", "utils_8c.html#aa312faca5a02b7660ca37777685775e6", null ],
    [ "transferBlock", "utils_8c.html#a4775d9ed63608cbe9760ef5033e43841", null ]
];