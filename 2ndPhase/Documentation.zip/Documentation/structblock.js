var structblock =
[
    [ "available", "structblock.html#a6a37485bfdca8f2d8b517b6b08cde1b3", null ],
    [ "leftSide", "structblock.html#a007afcf726de3e9c775b9305b38008b3", null ],
    [ "pnextBlock", "structblock.html#a63e26d8dbf410cfd13aed1b01f845b5a", null ],
    [ "prevBlock", "structblock.html#a10119ff2a20946cd8cc1431ecd510ab8", null ],
    [ "rightSide", "structblock.html#a29c530726dd9bf3d5744ddf422fa4d69", null ]
];