var structstringseq =
[
    [ "idSequence", "structstringseq.html#a76b44577b4d3ef13fa5324e43aa62d60", null ],
    [ "pnextStringSeq", "structstringseq.html#a2e754424c9c4c96bd51fc2491f4c1f35", null ],
    [ "sequence", "structstringseq.html#a12aa14ca491c4c8ea709aea6896ee1b5", null ],
    [ "sizeOfSequence", "structstringseq.html#af015b2c1567d849ff94d6b040aee7d32", null ]
];