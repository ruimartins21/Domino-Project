var structsequence =
[
    [ "pfirstBlock", "structsequence.html#ab0cab39b58da54157d9fbd624f69d950", null ],
    [ "pnextSequence", "structsequence.html#aff40dac4a15e71598dc08698a381ea5a", null ],
    [ "sizeOfSequence", "structsequence.html#af015b2c1567d849ff94d6b040aee7d32", null ]
];