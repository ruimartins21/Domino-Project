var structids =
[
    [ "firstId", "structids.html#a31d18bbf5e4da92fa5199eb6a99eff76", null ],
    [ "numberOfIds", "structids.html#a0e77fd4a62c4c4942a3e609a2cd9d053", null ]
];