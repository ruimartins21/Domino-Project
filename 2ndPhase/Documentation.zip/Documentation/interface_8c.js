var interface_8c =
[
    [ "blocksAvailable", "interface_8c.html#ad7eb9b38bce970ff07f85e0d625e6646", null ],
    [ "createPattern", "interface_8c.html#a0564dfca7981657862a4987f2ce23eed", null ],
    [ "createReplacePattern", "interface_8c.html#acbeaf3278cb6ea8a45ccfb876502d925", null ],
    [ "editHands", "interface_8c.html#abd263e497cf1de3949ac2a962e462eb0", null ],
    [ "findPatternInSequences", "interface_8c.html#ad701cb331975ccc9e5a43b60fe04d735", null ],
    [ "generateManualHand", "interface_8c.html#aeb4b48afd0b9f1c36133ab321f8e1158", null ],
    [ "printMenu", "interface_8c.html#a9c577b99d44fa36f27324ce664977c84", null ],
    [ "printSequence", "interface_8c.html#aa1e0e7d2e6818d640bc93934a99376de", null ],
    [ "printSequenceMatch", "interface_8c.html#ad12563b4fc4ae7bac0fd008b20c430d7", null ],
    [ "printSequenceOfSize", "interface_8c.html#ae3d0718ffa8a786c5bc25d09bf9f12bb", null ],
    [ "printSequences", "interface_8c.html#ad0fbbf7768bbb5392cbcb4f16f88d66c", null ]
];