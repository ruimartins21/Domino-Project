var files_8h =
[
    [ "createGameFile", "files_8h.html#acefd09826798045402f700f6909157cd", null ],
    [ "editFile", "files_8h.html#a881179eca642665a621350fb24f78dc9", null ],
    [ "openFile", "files_8h.html#af4a814d97e69145be930efdb9c55556b", null ],
    [ "saveSequencesInFile", "files_8h.html#a0d103824c53dc44ba6120530b80ddc50", null ]
];