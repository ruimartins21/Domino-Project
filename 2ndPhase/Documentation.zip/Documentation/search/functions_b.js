var searchData=
[
  ['savesequence',['saveSequence',['../core_8c.html#a53f900a4af1a8707d3ef92372810437a',1,'saveSequence(ALLSEQUENCES *allSequences, SEQUENCE pSequence):&#160;core.c'],['../core_8h.html#a53f900a4af1a8707d3ef92372810437a',1,'saveSequence(ALLSEQUENCES *allSequences, SEQUENCE pSequence):&#160;core.c']]],
  ['savesequencesinfile',['saveSequencesInFile',['../files_8c.html#a0d103824c53dc44ba6120530b80ddc50',1,'saveSequencesInFile(ALLSEQUENCES allSequences):&#160;files.c'],['../files_8h.html#a0d103824c53dc44ba6120530b80ddc50',1,'saveSequencesInFile(ALLSEQUENCES allSequences):&#160;files.c']]],
  ['sortallsequences',['sortAllSequences',['../core_8c.html#adaa92c2824d01474cc9ef9fd6ee9a715',1,'sortAllSequences(ALLSEQUENCES *allSequences):&#160;core.c'],['../core_8h.html#adaa92c2824d01474cc9ef9fd6ee9a715',1,'sortAllSequences(ALLSEQUENCES *allSequences):&#160;core.c']]],
  ['sortedmerge',['sortedMerge',['../core_8c.html#aa045058a46d98ff6235f5ff88c3743dd',1,'sortedMerge(STRINGSEQ *a, STRINGSEQ *b, unsigned long *costModel):&#160;core.c'],['../core_8h.html#aa045058a46d98ff6235f5ff88c3743dd',1,'sortedMerge(STRINGSEQ *a, STRINGSEQ *b, unsigned long *costModel):&#160;core.c']]],
  ['swapblock',['swapBlock',['../utils_8c.html#aa312faca5a02b7660ca37777685775e6',1,'swapBlock(GAME *game, BLOCK *handBlock, int index):&#160;utils.c'],['../utils_8h.html#aa312faca5a02b7660ca37777685775e6',1,'swapBlock(GAME *game, BLOCK *handBlock, int index):&#160;utils.c']]]
];
