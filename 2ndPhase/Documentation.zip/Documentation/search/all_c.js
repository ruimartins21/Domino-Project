var searchData=
[
  ['nextid',['nextId',['../structid.html#a511800f39b9b1916f5f22c75b26a36b2',1,'id']]],
  ['numberofhands',['numberOfHands',['../structhands.html#af4446c2199936f0e4e1ef256439da373',1,'hands']]],
  ['numberofids',['numberOfIds',['../structids.html#a0e77fd4a62c4c4942a3e609a2cd9d053',1,'ids']]],
  ['numberofsequences',['numberOfSequences',['../structall_sequences.html#a7de5f7ae6b194206fd712702d602eac3',1,'allSequences']]]
];
