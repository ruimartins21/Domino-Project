var searchData=
[
  ['kmp',['KMP',['../core_8c.html#ab57c65de8108e73db348b397089c9d3a',1,'KMP(STRINGSEQ text, char *pat, int print):&#160;core.c'],['../core_8h.html#ab57c65de8108e73db348b397089c9d3a',1,'KMP(STRINGSEQ text, char *pat, int print):&#160;core.c']]]
];
