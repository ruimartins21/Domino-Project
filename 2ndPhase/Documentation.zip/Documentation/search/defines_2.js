var searchData=
[
  ['r',['R',['../utils_8h.html#a5c71a5e59a53413cd6c270266d63b031',1,'utils.h']]]
];
