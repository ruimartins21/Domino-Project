var searchData=
[
  ['core_2ec',['core.c',['../core_8c.html',1,'']]],
  ['core_2eh',['core.h',['../core_8h.html',1,'']]]
];
