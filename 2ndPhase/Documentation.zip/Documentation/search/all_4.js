var searchData=
[
  ['editfile',['editFile',['../files_8c.html#a881179eca642665a621350fb24f78dc9',1,'editFile(char fileName[], int type, HANDS hands, GAME game):&#160;files.c'],['../files_8h.html#a881179eca642665a621350fb24f78dc9',1,'editFile(char fileName[], int type, HANDS hands, GAME game):&#160;files.c']]],
  ['edithands',['editHands',['../interface_8c.html#abd263e497cf1de3949ac2a962e462eb0',1,'editHands(HANDS *hands, GAME *game):&#160;interface.c'],['../interface_8h.html#abd263e497cf1de3949ac2a962e462eb0',1,'editHands(HANDS *hands, GAME *game):&#160;interface.c']]]
];
