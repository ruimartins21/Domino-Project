var searchData=
[
  ['sequence',['sequence',['../structsequence.html',1,'']]],
  ['stringseq',['stringseq',['../structstringseq.html',1,'']]]
];
