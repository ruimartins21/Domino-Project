var searchData=
[
  ['invertblock',['invertBlock',['../core_8c.html#a94e620286ef1fcc37a8a6cc9a987afd0',1,'invertBlock(BLOCK *pBlock):&#160;core.c'],['../core_8h.html#a94e620286ef1fcc37a8a6cc9a987afd0',1,'invertBlock(BLOCK *pBlock):&#160;core.c']]],
  ['invertblocksequence',['invertBlockSequence',['../core_8c.html#a0d424bf74426b636fc77b2ed2005b364',1,'invertBlockSequence(SEQUENCE *pSequence):&#160;core.c'],['../core_8h.html#a0d424bf74426b636fc77b2ed2005b364',1,'invertBlockSequence(SEQUENCE *pSequence):&#160;core.c']]],
  ['isconsistent',['isConsistent',['../core_8c.html#a76d1e7c8b439998f7cc5eee00697882b',1,'isConsistent(SEQUENCE *pSequence, BLOCK *newBlock, int inserted):&#160;core.c'],['../core_8h.html#a76d1e7c8b439998f7cc5eee00697882b',1,'isConsistent(SEQUENCE *pSequence, BLOCK *newBlock, int inserted):&#160;core.c']]]
];
