var searchData=
[
  ['r',['R',['../utils_8h.html#a5c71a5e59a53413cd6c270266d63b031',1,'utils.h']]],
  ['removeblock',['removeBlock',['../utils_8c.html#afe6153a014b851d29f0bff3366ae182e',1,'removeBlock(GAME *game, BLOCK block):&#160;utils.c'],['../utils_8h.html#afe6153a014b851d29f0bff3366ae182e',1,'removeBlock(GAME *game, BLOCK block):&#160;utils.c']]],
  ['replacepattern',['replacePattern',['../core_8c.html#a116d1a736a995f73b682774ab82b4711',1,'replacePattern(ALLSEQUENCES *allSequences, IDS *sequenceIds, char *pattern, char *replace):&#160;core.c'],['../core_8h.html#a116d1a736a995f73b682774ab82b4711',1,'replacePattern(ALLSEQUENCES *allSequences, IDS *sequenceIds, char *pattern, char *replace):&#160;core.c']]],
  ['rightside',['rightSide',['../structblock.html#a29c530726dd9bf3d5744ddf422fa4d69',1,'block']]]
];
