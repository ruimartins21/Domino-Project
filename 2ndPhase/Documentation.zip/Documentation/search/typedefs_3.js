var searchData=
[
  ['hand',['HAND',['../utils_8h.html#aee8748e4b6a7bf0a98eda2a72647e589',1,'utils.h']]],
  ['hands',['HANDS',['../utils_8h.html#adfc3dbc45dc4535e8277b12cfdafc55c',1,'utils.h']]]
];
