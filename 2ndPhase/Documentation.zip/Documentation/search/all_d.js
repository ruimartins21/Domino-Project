var searchData=
[
  ['openfile',['openFile',['../files_8c.html#af4a814d97e69145be930efdb9c55556b',1,'openFile(char fileName[], int type, HANDS *hands, GAME *game):&#160;files.c'],['../files_8h.html#af4a814d97e69145be930efdb9c55556b',1,'openFile(char fileName[], int type, HANDS *hands, GAME *game):&#160;files.c']]]
];
