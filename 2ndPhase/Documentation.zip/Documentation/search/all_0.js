var searchData=
[
  ['allsequences',['allSequences',['../structall_sequences.html',1,'allSequences'],['../utils_8h.html#a60418dbece233e697760fb351ae824c0',1,'ALLSEQUENCES():&#160;utils.h']]],
  ['available',['available',['../structblock.html#a6a37485bfdca8f2d8b517b6b08cde1b3',1,'block']]],
  ['availableblocks',['availableBlocks',['../structgame.html#a57b1f508ebec8df5e9f86bef107dd3f4',1,'game']]]
];
