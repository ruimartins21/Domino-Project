var searchData=
[
  ['savesequence',['saveSequence',['../core_8c.html#a53f900a4af1a8707d3ef92372810437a',1,'saveSequence(ALLSEQUENCES *allSequences, SEQUENCE pSequence):&#160;core.c'],['../core_8h.html#a53f900a4af1a8707d3ef92372810437a',1,'saveSequence(ALLSEQUENCES *allSequences, SEQUENCE pSequence):&#160;core.c']]],
  ['savesequencesinfile',['saveSequencesInFile',['../files_8c.html#a0d103824c53dc44ba6120530b80ddc50',1,'saveSequencesInFile(ALLSEQUENCES allSequences):&#160;files.c'],['../files_8h.html#a0d103824c53dc44ba6120530b80ddc50',1,'saveSequencesInFile(ALLSEQUENCES allSequences):&#160;files.c']]],
  ['sequence',['sequence',['../structsequence.html',1,'sequence'],['../structstringseq.html#a12aa14ca491c4c8ea709aea6896ee1b5',1,'stringseq::sequence()'],['../utils_8h.html#a97a1b2de1da92cbb6174ff75c1e1b8df',1,'SEQUENCE():&#160;utils.h']]],
  ['sequenceid',['sequenceId',['../structid.html#a29a9ae3c0d65ee87ce4889224cb8ca74',1,'id']]],
  ['sizeofsequence',['sizeOfSequence',['../structsequence.html#af015b2c1567d849ff94d6b040aee7d32',1,'sequence::sizeOfSequence()'],['../structstringseq.html#af015b2c1567d849ff94d6b040aee7d32',1,'stringseq::sizeOfSequence()']]],
  ['sortallsequences',['sortAllSequences',['../core_8c.html#adaa92c2824d01474cc9ef9fd6ee9a715',1,'sortAllSequences(ALLSEQUENCES *allSequences):&#160;core.c'],['../core_8h.html#adaa92c2824d01474cc9ef9fd6ee9a715',1,'sortAllSequences(ALLSEQUENCES *allSequences):&#160;core.c']]],
  ['sortedmerge',['sortedMerge',['../core_8c.html#aa045058a46d98ff6235f5ff88c3743dd',1,'sortedMerge(STRINGSEQ *a, STRINGSEQ *b, unsigned long *costModel):&#160;core.c'],['../core_8h.html#aa045058a46d98ff6235f5ff88c3743dd',1,'sortedMerge(STRINGSEQ *a, STRINGSEQ *b, unsigned long *costModel):&#160;core.c']]],
  ['stringseq',['stringseq',['../structstringseq.html',1,'stringseq'],['../utils_8h.html#a98bcaf834d239f598b9b19c74db77015',1,'STRINGSEQ():&#160;utils.h']]],
  ['swapblock',['swapBlock',['../utils_8c.html#aa312faca5a02b7660ca37777685775e6',1,'swapBlock(GAME *game, BLOCK *handBlock, int index):&#160;utils.c'],['../utils_8h.html#aa312faca5a02b7660ca37777685775e6',1,'swapBlock(GAME *game, BLOCK *handBlock, int index):&#160;utils.c']]]
];
