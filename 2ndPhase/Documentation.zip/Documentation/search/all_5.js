var searchData=
[
  ['fileexists',['fileExists',['../utils_8c.html#a33cb94f417fea8099841cefc9162542f',1,'fileExists(char fileName[]):&#160;utils.c'],['../utils_8h.html#a33cb94f417fea8099841cefc9162542f',1,'fileExists(char fileName[]):&#160;utils.c']]],
  ['files_2ec',['files.c',['../files_8c.html',1,'']]],
  ['files_2eh',['files.h',['../files_8h.html',1,'']]],
  ['findpatterninsequences',['findPatternInSequences',['../interface_8c.html#ad701cb331975ccc9e5a43b60fe04d735',1,'findPatternInSequences(ALLSEQUENCES allSequences, char *pattern, IDS *sequenceIds, unsigned long *numberOfMatches):&#160;interface.c'],['../interface_8h.html#ad701cb331975ccc9e5a43b60fe04d735',1,'findPatternInSequences(ALLSEQUENCES allSequences, char *pattern, IDS *sequenceIds, unsigned long *numberOfMatches):&#160;interface.c']]],
  ['findsequenceofsize',['findSequenceOfSize',['../core_8c.html#a4ae56a73a9019245e1d3ea77f13d3e5e',1,'findSequenceOfSize(ALLSEQUENCES allSequences, int size, unsigned long *costModel):&#160;core.c'],['../core_8h.html#a4ae56a73a9019245e1d3ea77f13d3e5e',1,'findSequenceOfSize(ALLSEQUENCES allSequences, int size, unsigned long *costModel):&#160;core.c']]],
  ['firstid',['firstId',['../structids.html#a31d18bbf5e4da92fa5199eb6a99eff76',1,'ids']]],
  ['freegame',['freeGame',['../utils_8c.html#a20c023462aa6e20125f7533b28a991ed',1,'freeGame(GAME *game):&#160;utils.c'],['../utils_8h.html#a20c023462aa6e20125f7533b28a991ed',1,'freeGame(GAME *game):&#160;utils.c']]],
  ['frontbacksplit',['frontBackSplit',['../core_8c.html#aa801ead16a3e9df5be4983289e64d480',1,'frontBackSplit(STRINGSEQ *source, STRINGSEQ **frontRef, STRINGSEQ **backRef):&#160;core.c'],['../core_8h.html#aa801ead16a3e9df5be4983289e64d480',1,'frontBackSplit(STRINGSEQ *source, STRINGSEQ **frontRef, STRINGSEQ **backRef):&#160;core.c']]]
];
