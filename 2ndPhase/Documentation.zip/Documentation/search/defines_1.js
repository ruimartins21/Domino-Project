var searchData=
[
  ['path',['PATH',['../utils_8h.html#ab0139008fdda107456f13f837872b410',1,'utils.h']]]
];
