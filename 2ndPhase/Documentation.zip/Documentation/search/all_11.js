var searchData=
[
  ['transferblock',['transferBlock',['../utils_8c.html#a4775d9ed63608cbe9760ef5033e43841',1,'transferBlock(BLOCK *delBlock):&#160;utils.c'],['../utils_8h.html#a4775d9ed63608cbe9760ef5033e43841',1,'transferBlock(BLOCK *delBlock):&#160;utils.c']]]
];
