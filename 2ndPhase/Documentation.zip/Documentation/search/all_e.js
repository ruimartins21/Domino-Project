var searchData=
[
  ['path',['PATH',['../utils_8h.html#ab0139008fdda107456f13f837872b410',1,'utils.h']]],
  ['peepblock',['peepBlock',['../utils_8c.html#a8307b43310348ab186bb20ed4a9f116b',1,'peepBlock(GAME game, int index):&#160;utils.c'],['../utils_8h.html#a8307b43310348ab186bb20ed4a9f116b',1,'peepBlock(GAME game, int index):&#160;utils.c']]],
  ['pfirstblock',['pfirstBlock',['../structgame.html#ab0cab39b58da54157d9fbd624f69d950',1,'game::pfirstBlock()'],['../structhand.html#ab0cab39b58da54157d9fbd624f69d950',1,'hand::pfirstBlock()'],['../structsequence.html#ab0cab39b58da54157d9fbd624f69d950',1,'sequence::pfirstBlock()']]],
  ['pfirsthand',['pfirstHand',['../structhands.html#a0d0a0e096282f49bde6336b16c06fc71',1,'hands']]],
  ['pfirstsequence',['pfirstSequence',['../structall_sequences.html#a3750d9faa96e3725f9ec9e40429c3eed',1,'allSequences']]],
  ['pnextblock',['pnextBlock',['../structblock.html#a63e26d8dbf410cfd13aed1b01f845b5a',1,'block']]],
  ['pnexthand',['pnextHand',['../structhand.html#a8a6476bcebc1aef75b4a4afacae7ecec',1,'hand']]],
  ['pnextsequence',['pnextSequence',['../structsequence.html#aff40dac4a15e71598dc08698a381ea5a',1,'sequence']]],
  ['pnextstringseq',['pnextStringSeq',['../structstringseq.html#a2e754424c9c4c96bd51fc2491f4c1f35',1,'stringseq']]],
  ['popblock',['popBlock',['../utils_8c.html#a718b153ac66cdc04c92b9344f6c2efca',1,'popBlock(GAME *game, int index):&#160;utils.c'],['../utils_8h.html#a718b153ac66cdc04c92b9344f6c2efca',1,'popBlock(GAME *game, int index):&#160;utils.c']]],
  ['prekmp',['preKMP',['../core_8c.html#a21898f020fd64fc9ea2cf99243ef508c',1,'preKMP(char *pat, int dfa[][MAX28]):&#160;core.c'],['../core_8h.html#a21898f020fd64fc9ea2cf99243ef508c',1,'preKMP(char *pat, int dfa[][MAX28]):&#160;core.c']]],
  ['prevblock',['prevBlock',['../structblock.html#a10119ff2a20946cd8cc1431ecd510ab8',1,'block']]],
  ['printmenu',['printMenu',['../interface_8c.html#a9c577b99d44fa36f27324ce664977c84',1,'printMenu(int path):&#160;interface.c'],['../interface_8h.html#a9c577b99d44fa36f27324ce664977c84',1,'printMenu(int path):&#160;interface.c']]],
  ['printsequence',['printSequence',['../interface_8c.html#aa1e0e7d2e6818d640bc93934a99376de',1,'printSequence(SEQUENCE sequence):&#160;interface.c'],['../interface_8h.html#aa1e0e7d2e6818d640bc93934a99376de',1,'printSequence(SEQUENCE sequence):&#160;interface.c']]],
  ['printsequencematch',['printSequenceMatch',['../interface_8c.html#ad12563b4fc4ae7bac0fd008b20c430d7',1,'printSequenceMatch(STRINGSEQ text, int index, int length, int withId):&#160;interface.c'],['../interface_8h.html#ad12563b4fc4ae7bac0fd008b20c430d7',1,'printSequenceMatch(STRINGSEQ text, int index, int length, int withId):&#160;interface.c']]],
  ['printsequenceofsize',['printSequenceOfSize',['../interface_8c.html#ae3d0718ffa8a786c5bc25d09bf9f12bb',1,'printSequenceOfSize(STRINGSEQ sequence, int size):&#160;interface.c'],['../interface_8h.html#ae3d0718ffa8a786c5bc25d09bf9f12bb',1,'printSequenceOfSize(STRINGSEQ sequence, int size):&#160;interface.c']]],
  ['printsequences',['printSequences',['../interface_8c.html#ad0fbbf7768bbb5392cbcb4f16f88d66c',1,'printSequences(ALLSEQUENCES allSequences, int size):&#160;interface.c'],['../interface_8h.html#ad0fbbf7768bbb5392cbcb4f16f88d66c',1,'printSequences(ALLSEQUENCES allSequences, int size):&#160;interface.c']]],
  ['printsinglehand',['printSingleHand',['../utils_8c.html#ab2dd5cfe4f26be348d94206ef04db5df',1,'printSingleHand(HAND hand, int handSize):&#160;utils.c'],['../utils_8h.html#ab2dd5cfe4f26be348d94206ef04db5df',1,'printSingleHand(HAND hand, int handSize):&#160;utils.c']]]
];
