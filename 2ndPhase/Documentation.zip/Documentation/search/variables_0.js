var searchData=
[
  ['available',['available',['../structblock.html#a6a37485bfdca8f2d8b517b6b08cde1b3',1,'block']]],
  ['availableblocks',['availableBlocks',['../structgame.html#a57b1f508ebec8df5e9f86bef107dd3f4',1,'game']]]
];
