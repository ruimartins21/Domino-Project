var searchData=
[
  ['id',['id',['../structid.html',1,'id'],['../utils_8h.html#af48c403241d1e46d8b5e7b3e7b5429f4',1,'ID():&#160;utils.h']]],
  ['ids',['ids',['../structids.html',1,'ids'],['../utils_8h.html#ae98f6179cc6b10da538fb718288468b4',1,'IDS():&#160;utils.h']]],
  ['idsequence',['idSequence',['../structstringseq.html#a76b44577b4d3ef13fa5324e43aa62d60',1,'stringseq']]],
  ['interface_2ec',['interface.c',['../interface_8c.html',1,'']]],
  ['interface_2eh',['interface.h',['../interface_8h.html',1,'']]],
  ['invertblock',['invertBlock',['../core_8c.html#a94e620286ef1fcc37a8a6cc9a987afd0',1,'invertBlock(BLOCK *pBlock):&#160;core.c'],['../core_8h.html#a94e620286ef1fcc37a8a6cc9a987afd0',1,'invertBlock(BLOCK *pBlock):&#160;core.c']]],
  ['invertblocksequence',['invertBlockSequence',['../core_8c.html#a0d424bf74426b636fc77b2ed2005b364',1,'invertBlockSequence(SEQUENCE *pSequence):&#160;core.c'],['../core_8h.html#a0d424bf74426b636fc77b2ed2005b364',1,'invertBlockSequence(SEQUENCE *pSequence):&#160;core.c']]],
  ['isconsistent',['isConsistent',['../core_8c.html#a76d1e7c8b439998f7cc5eee00697882b',1,'isConsistent(SEQUENCE *pSequence, BLOCK *newBlock, int inserted):&#160;core.c'],['../core_8h.html#a76d1e7c8b439998f7cc5eee00697882b',1,'isConsistent(SEQUENCE *pSequence, BLOCK *newBlock, int inserted):&#160;core.c']]]
];
