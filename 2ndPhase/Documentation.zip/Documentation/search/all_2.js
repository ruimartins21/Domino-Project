var searchData=
[
  ['checkextension',['checkExtension',['../utils_8c.html#a382054c8b29508312045af99e9b7b211',1,'checkExtension(char fileName[], char extension[]):&#160;utils.c'],['../utils_8h.html#a382054c8b29508312045af99e9b7b211',1,'checkExtension(char fileName[], char extension[]):&#160;utils.c']]],
  ['checkid',['checkId',['../utils_8c.html#a3785675cf18028084070b6b9084ef30d',1,'checkId(IDS *sequenceIds, unsigned long id):&#160;utils.c'],['../utils_8h.html#a3785675cf18028084070b6b9084ef30d',1,'checkId(IDS *sequenceIds, unsigned long id):&#160;utils.c']]],
  ['core_2ec',['core.c',['../core_8c.html',1,'']]],
  ['core_2eh',['core.h',['../core_8h.html',1,'']]],
  ['createdynamicstring',['createDynamicString',['../utils_8c.html#a9c595b6230e08769d7c1560f3707e7a7',1,'createDynamicString(char str[]):&#160;utils.c'],['../utils_8h.html#a9c595b6230e08769d7c1560f3707e7a7',1,'createDynamicString(char str[]):&#160;utils.c']]],
  ['creategamefile',['createGameFile',['../files_8c.html#acefd09826798045402f700f6909157cd',1,'createGameFile(int type, HANDS hands, GAME game):&#160;files.c'],['../files_8h.html#acefd09826798045402f700f6909157cd',1,'createGameFile(int type, HANDS hands, GAME game):&#160;files.c']]],
  ['createpattern',['createPattern',['../interface_8c.html#a0564dfca7981657862a4987f2ce23eed',1,'createPattern(ALLSEQUENCES allSequences, int maxSequenceSize):&#160;interface.c'],['../interface_8h.html#a0564dfca7981657862a4987f2ce23eed',1,'createPattern(ALLSEQUENCES allSequences, int maxSequenceSize):&#160;interface.c']]],
  ['createreplacepattern',['createReplacePattern',['../interface_8c.html#acbeaf3278cb6ea8a45ccfb876502d925',1,'createReplacePattern(ALLSEQUENCES allSequences, IDS sequenceIds, char *pattern):&#160;interface.c'],['../interface_8h.html#acbeaf3278cb6ea8a45ccfb876502d925',1,'createReplacePattern(ALLSEQUENCES allSequences, IDS sequenceIds, char *pattern):&#160;interface.c']]]
];
