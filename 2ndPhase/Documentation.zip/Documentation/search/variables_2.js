var searchData=
[
  ['handsize',['handSize',['../structhands.html#a6a41adec09324340da417006bb873ba4',1,'hands']]]
];
