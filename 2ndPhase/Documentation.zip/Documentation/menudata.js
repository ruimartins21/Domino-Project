var menudata={children:[
{text:'Main Page',url:'index.html'},
{text:'Data Structures',url:'annotated.html',children:[
{text:'Data Structures',url:'annotated.html'},
{text:'Data Structure Index',url:'classes.html'},
{text:'Data Fields',url:'functions.html',children:[
{text:'All',url:'functions.html'},
{text:'Variables',url:'functions_vars.html'}]}]},
{text:'Files',url:'files.html',children:[
{text:'File List',url:'files.html'},
{text:'Globals',url:'globals.html',children:[
{text:'All',url:'globals.html',children:[
{text:'a',url:'globals.html#index_a'},
{text:'b',url:'globals.html#index_b'},
{text:'c',url:'globals.html#index_c'},
{text:'e',url:'globals.html#index_e'},
{text:'f',url:'globals.html#index_f'},
{text:'g',url:'globals.html#index_g'},
{text:'h',url:'globals.html#index_h'},
{text:'i',url:'globals.html#index_i'},
{text:'k',url:'globals.html#index_k'},
{text:'m',url:'globals.html#index_m'},
{text:'o',url:'globals.html#index_o'},
{text:'p',url:'globals.html#index_p'},
{text:'r',url:'globals.html#index_r'},
{text:'s',url:'globals.html#index_s'},
{text:'t',url:'globals.html#index_t'}]},
{text:'Functions',url:'globals_func.html',children:[
{text:'b',url:'globals_func.html#index_b'},
{text:'c',url:'globals_func.html#index_c'},
{text:'e',url:'globals_func.html#index_e'},
{text:'f',url:'globals_func.html#index_f'},
{text:'g',url:'globals_func.html#index_g'},
{text:'i',url:'globals_func.html#index_i'},
{text:'k',url:'globals_func.html#index_k'},
{text:'m',url:'globals_func.html#index_m'},
{text:'o',url:'globals_func.html#index_o'},
{text:'p',url:'globals_func.html#index_p'},
{text:'r',url:'globals_func.html#index_r'},
{text:'s',url:'globals_func.html#index_s'},
{text:'t',url:'globals_func.html#index_t'}]},
{text:'Typedefs',url:'globals_type.html'},
{text:'Macros',url:'globals_defs.html'}]}]}]}
