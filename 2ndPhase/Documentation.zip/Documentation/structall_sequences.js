var structall_sequences =
[
    [ "numberOfSequences", "structall_sequences.html#a7de5f7ae6b194206fd712702d602eac3", null ],
    [ "pfirstSequence", "structall_sequences.html#a3750d9faa96e3725f9ec9e40429c3eed", null ]
];