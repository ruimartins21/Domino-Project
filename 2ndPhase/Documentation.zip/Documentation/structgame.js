var structgame =
[
    [ "availableBlocks", "structgame.html#a57b1f508ebec8df5e9f86bef107dd3f4", null ],
    [ "pfirstBlock", "structgame.html#ab0cab39b58da54157d9fbd624f69d950", null ]
];