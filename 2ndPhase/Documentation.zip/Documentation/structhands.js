var structhands =
[
    [ "handSize", "structhands.html#a6a41adec09324340da417006bb873ba4", null ],
    [ "numberOfHands", "structhands.html#af4446c2199936f0e4e1ef256439da373", null ],
    [ "pfirstHand", "structhands.html#a0d0a0e096282f49bde6336b16c06fc71", null ]
];