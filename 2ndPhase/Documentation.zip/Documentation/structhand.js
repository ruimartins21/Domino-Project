var structhand =
[
    [ "pfirstBlock", "structhand.html#ab0cab39b58da54157d9fbd624f69d950", null ],
    [ "pnextHand", "structhand.html#a8a6476bcebc1aef75b4a4afacae7ecec", null ]
];