var annotated_dup =
[
    [ "allSequences", "structall_sequences.html", "structall_sequences" ],
    [ "block", "structblock.html", "structblock" ],
    [ "game", "structgame.html", "structgame" ],
    [ "hand", "structhand.html", "structhand" ],
    [ "hands", "structhands.html", "structhands" ],
    [ "id", "structid.html", "structid" ],
    [ "ids", "structids.html", "structids" ],
    [ "sequence", "structsequence.html", "structsequence" ],
    [ "stringseq", "structstringseq.html", "structstringseq" ]
];