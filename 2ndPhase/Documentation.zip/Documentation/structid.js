var structid =
[
    [ "nextId", "structid.html#a511800f39b9b1916f5f22c75b26a36b2", null ],
    [ "sequenceId", "structid.html#a29a9ae3c0d65ee87ce4889224cb8ca74", null ]
];